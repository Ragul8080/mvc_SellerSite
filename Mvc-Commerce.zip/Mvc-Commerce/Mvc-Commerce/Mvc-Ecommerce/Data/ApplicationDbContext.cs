﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Mvc_Ecommerce.Models;

namespace Mvc_Ecommerce.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Product> Products { get; set; }

        public DbSet<Category> Categories { get; set; }

        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        public DbSet<Types> Types { get; set; }
        public DbSet<ProductType> ProductTypes { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //  composite key and relationships for ProductIngredient
            modelBuilder.Entity<ProductType>()
                .HasKey(pi => new { pi.ProductId, pi.TypeId });

            modelBuilder.Entity<ProductType>()
                .HasOne(pi => pi.Product)
                .WithMany(p => p.ProductTypes)
                .HasForeignKey(pi => pi.ProductId);

            modelBuilder.Entity<ProductType>()
                .HasOne(pi => pi.Types)
                .WithMany(i => i.ProductTypes)
                .HasForeignKey(pi => pi.TypeId);
            modelBuilder.Entity<Order>()
                .HasKey(o => o.OrderId); // Specify the primary key
            modelBuilder.Entity<Types>()
                .HasKey(t => t.TypeId); // Define TypeId as the primary key

            //Seed Data

            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = 1, Name = "Laptop" },
                new Category { CategoryId = 2, Name = "Mobile" },
                new Category { CategoryId = 7, Name = "Tablet" }
                );

            modelBuilder.Entity<Types>().HasData(
                new Types { TypeId = 1, Name = "IPhone" },
                new Types { TypeId = 2, Name = "Samsung" },
                new Types { TypeId = 3, Name = "Redmi" },
                new Types { TypeId = 4, Name = "Oppo" },
                new Types { TypeId = 5, Name = "Mac" },
                new Types { TypeId = 6, Name = "Dell" },
                new Types { TypeId = 7, Name = "Asus" },
                new Types { TypeId = 8, Name = "Acer" },
                new Types { TypeId = 9, Name = "lenovo" },
                new Types { TypeId = 10, Name = "Vivo" },
                new Types { TypeId = 11, Name = "Hp" }
                );

            modelBuilder.Entity<Product>().HasData(

                //Add mexican restaurant food entries here
                new Product
                {
                    ProductId = 1,
                    Name = "Redmi 12 5g",
                    Description = "16gb Ram",
                    Price = 2.50m,
                    Stock = 100,
                    CategoryId = 2
                },
                new Product
                {
                    ProductId = 2,
                    Name = "Redmi note 7",
                    Description = "16gb Ram",
                    Price = 2.50m,
                    Stock = 100,
                    CategoryId = 2
                },
                new Product
                {
                    ProductId = 3,
                    Name = "IPhone 16 pro max",
                    Description = "8gb Ram",
                    Price = 1.99m,
                    Stock = 101,
                    CategoryId = 2
                },
                new Product
                {
                    ProductId = 4,
                    Name = "Dell latitude",
                    Description = "16gb Ram , i5 procce",
                    Price = 3.99m,
                    Stock = 90,
                    CategoryId = 2
                }
                );
            modelBuilder.Entity<ProductType>().HasData(
                new ProductType { ProductId = 1, TypeId = 3 },
                new ProductType { ProductId = 2, TypeId = 3 },
                new ProductType { ProductId = 3, TypeId = 1 },
                new ProductType { ProductId = 4, TypeId = 6 }

                );

        }
    }
}