﻿using Microsoft.AspNetCore.Mvc;
using Mvc_Ecommerce.Models;
using Mvc_Ecommerce.Data;
namespace Mvc_Ecommerce.Controllers
{
    public class TypeController : Controller
    {
        private Repository<Types> Types;

        public TypeController(ApplicationDbContext context)
        {
            Types = new Repository<Types>(context); 
        }




        public async Task <IActionResult> Index()
        {
            return View(await Types.GetAllAsync());
        }

        public async Task<IActionResult> Details(int id)
        {
            return View(await Types.GetByIdAsync(id, new QueryOptions<Types>() { Includes = "ProductTypes.Product" }));

        }

       [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TypeId, Name")] Types Brand)
        {
            if (ModelState.IsValid)
            {
                await Types.AddAsync(Brand);
                return RedirectToAction("Index");
            }
            return View(Brand);
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            return View(await Types.GetByIdAsync(id, new QueryOptions<Types> { Includes = "ProductTypes.Product" }));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(Types Brand)
        {
            await Types.DeleteAsync(Brand.TypeId);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            return View(await Types.GetByIdAsync(id, new QueryOptions<Types> { Includes = "ProductTypes.Product" }));
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Types Brand) // Change Type to Types
        {
            if (ModelState.IsValid)
            {
                await Types.UpdateAsync(Brand);
                return RedirectToAction("Index");
            }
            return View(Brand);
        }

    }
}
