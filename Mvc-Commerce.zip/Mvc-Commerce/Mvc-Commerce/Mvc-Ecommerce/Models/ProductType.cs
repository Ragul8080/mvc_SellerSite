﻿namespace Mvc_Ecommerce.Models
{
    public class ProductType
    {
        public int ProductId { get; set; }
        public Product Product { get; set; }
        public int TypeId { get; set; }
        public Types Types { get; set; }
    }
}
 