﻿using Microsoft.AspNetCore.Identity;

namespace Mvc_Ecommerce.Models
{
    public class ApplicationUser : IdentityUser
    {
        public ICollection<Order>? Orders { get; set; }


    }
}
