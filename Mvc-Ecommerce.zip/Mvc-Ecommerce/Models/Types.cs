﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace Mvc_Ecommerce.Models
{
    public class Types
    {
        public int TypeId { get; set; } // Primary Key
        public string Name { get; set; }
        [ValidateNever]
        public ICollection<ProductType>ProductTypes{  get; set; }
        

    }
}